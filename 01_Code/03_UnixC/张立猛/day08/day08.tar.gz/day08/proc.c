#include <stdio.h>
#include <unistd.h>

int main(){
  printf("cpid=%d\n",getpid());
}

