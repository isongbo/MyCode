#include <stdio.h>

int main(){
  printf("hello c\n");
}

