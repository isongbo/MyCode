#ifndef _COMMON_H
#define _COMMON_H
void sigchld (int signum);
#endif // _COMMON_H
