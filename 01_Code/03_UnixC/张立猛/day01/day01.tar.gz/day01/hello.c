#include <stdio.h>//C编译器很宽松

int main(){
  printf("hello c\n");
  return 0;
  //sdfafdafdafda();
  //int a = 10;
  //if(0<a<5){//隐藏了很多错误
     //printf("test\n");
  //}
}

