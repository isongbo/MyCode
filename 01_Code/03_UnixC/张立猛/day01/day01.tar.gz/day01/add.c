int add(int a,int b){
  return a+b;
}
double add2(double a,double b){
  return a+b;
}

