#ifndef _ADD_H //防止重复导入
#define _ADD_H

int add(int,int);
double add2(double,double);

#endif//练习：写add.c做实现，不需要主函数
