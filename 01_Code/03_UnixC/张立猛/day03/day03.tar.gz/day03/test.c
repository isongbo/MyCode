#include <stdio.h>

int a = 10;
int main(){
  printf("&a=%p\n",&a);
  while(1);
}

