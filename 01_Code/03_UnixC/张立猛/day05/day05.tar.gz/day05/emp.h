#ifndef _EMP_H
#define _EMP_H
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
struct emp{ //类型是struct emp
  int id;
  char name[20];
  double sal;
};

#endif
