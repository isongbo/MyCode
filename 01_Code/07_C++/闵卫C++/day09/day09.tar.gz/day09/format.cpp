#include <cmath>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
int main (void) {
	cout << sqrt (200) << endl;
	cout.precision (10);
	cout << sqrt (200) << endl;
	cout.setf (ios::scientific);
	cout << sqrt (200) << endl;
	cout << setprecision (8) << sqrt (200) << endl;
	cout << oct << 127 << endl;
	cout << hex << 127 << endl;
	cout << dec << 127 << endl;
	cout << '[' << setw (10) << 256 << ']' << endl;
	cout << '[' << setw (10) << left << 256 << ']'
		<< endl;
	cout << '[' << setfill ('_') << setw (10)
		<< 256 << ']' << endl;
	cout << '[' << setw (10) << 345 << ']'
		<< '[' << 678 << ']' << endl;
	ifstream ifs ("i.txt");
	ifs.unsetf (ios::skipws);
	char c;
	while (ifs >> c)
		cout << c;
	cout << endl;
	ifs.close ();
	return 0;
}
