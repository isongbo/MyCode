#include <cstdio>
#include <iostream>
#include <fstream>
using namespace std;
int main (void) {
	ofstream ofs ("text.txt");
	if (! ofs)
		perror ("打开文件失败");
	ofs << 1234 << ' ' << 56.78 << ' '
		<< "apples" << endl;
	ofs.close ();
	ofs.open ("text.txt", ios::app);
	if (! ofs)
		perror ("打开文件失败");
	ofs << "append_a_line" << endl;
	ofs.close ();
	ifstream ifs ("text.txt");
	if (! ifs)
		perror ("打开文件失败");
	int i;
	double d;
	string s1, s2;
	ifs >> i >> d >> s1 >> s2;
	cout << i << endl;
	cout << d << endl;
	cout << s1 << endl;
	cout << s2 << endl;
	ifs.close ();
	return 0;
}
