#include <cstdlib>
#include <iostream>
using namespace std;
void foo (int a) throw (float, int,double,string);
//void foo (int a) throw (int, double, string) {
void foo (int a) throw (int,double,float,string){
//void foo (int a) throw () {
//void foo (int a) {
	if (a == 1)
		throw 1;
	else if (a == 2)
		throw 3.14;
	else if (a == 3)
		throw string ("Hello, World !");
	else
		throw 3.14f;
}
int main (int argc, char* argv[]) {
	try {
		foo (atoi (argv[1]));
	}
	catch (int& ex) {
		cout << ex << endl;
	}
	catch (double& ex) {
		cout << ex << endl;
	}
	catch (string& ex) {
		cout << ex << endl;
	}
	catch (float& ex) {
		cout << ex << endl;
	}
	catch (...) {
		cout << "其它异常！" << endl;
	}
	return 0;
}
