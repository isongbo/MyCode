#include <iostream>
#include <fstream>
using namespace std;
int main (void) {
	fstream fs ("seek.txt", ios::in | ios::out);
	fs << "0123456789";
	fs.seekp (-7, ios::cur);
	cout << "当前位置：" << fs.tellp () << endl;
	cout << "当前位置：" << fs.tellg () << endl;
	fs << "ABCD";
	fs.seekg (ios::beg);
	cout << "当前位置：" << fs.tellg () << endl;
	cout << "当前位置：" << fs.tellp () << endl;
//	fs.seekg (0, ios::beg);
	int i;
	fs >> i;
	cout << i << endl; // 12
	return 0;
}
