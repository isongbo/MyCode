#include <cstdio>
#include <iostream>
#include <fstream>
using namespace std;
int main (int argc, char* argv[]) {
	if (argc < 3) {
		cout << "用法：" << argv[0]
			<< " <源文件> <目的文件>" << endl;
		return -1;
	}
	ifstream ifs (argv[1], ios::binary);
	if (! ifs) {
		perror ("打开源文件失败");
		return -1;
	}
	ofstream ofs (argv[2], ios::binary);
	if (! ofs) {
		perror ("打开目的文件失败");
		return -1;
	}
	char buf[1024];
	while (ifs.read (buf, 1024))
		ofs.write (buf, 1024);
	if (ifs.eof ())
		ofs.write (buf, ifs.gcount ());
	else
		perror ("读取源文件失败");
	ofs.close ();
	ifs.close ();
	return 0;
}
