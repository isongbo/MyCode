#include <iostream>
using namespace std;
typedef void (*VFUN) (void*);
typedef VFUN* VPTR;
class A {
public:
	A (int data) : m_data (data) {
		cout << "A构造" << endl;
		VPTR vptr = *(VPTR*)this;
		cout << vptr << "->" << (void*)vptr[0]
			<< ',' << (void*)vptr[1] << endl;
	}
	~A (void) {
		cout << "A析构" << endl;
		VPTR vptr = *(VPTR*)this;
		cout << vptr << "->" << (void*)vptr[0]
			<< ',' << (void*)vptr[1] << endl;
	}
	virtual void foo (void) {
		cout << "A::foo：" << m_data << endl;
	}
	virtual void bar (void) {
		cout << "A::bar：" << m_data << endl;
	}
protected:
	int m_data;
};
class B : public A {
public:
	B (int data) : A (data) {
		cout << "B构造" << endl;
		VPTR vptr = *(VPTR*)this;
		cout << vptr << "->" << (void*)vptr[0]
			<< ',' << (void*)vptr[1] << endl;
	}
	~B (void) {
		cout << "B析构" << endl;
		VPTR vptr = *(VPTR*)this;
		cout << vptr << "->" << (void*)vptr[0]
			<< ',' << (void*)vptr[1] << endl;
	}
	void foo (void) {
		cout << "B::foo：" << m_data << endl;
	}
};
int main (void) {
	A a (100);
	a.foo ();
	a.bar ();
	B b (200);
	b.foo ();
	b.bar ();
	A& r = b;
	r.foo ();
	r.bar ();
	cout << "----------------" << endl;
	VPTR vptr = *(VPTR*)&a;
	cout << "A之虚表指针：" << vptr << endl;
	cout << (void*)vptr[0] << ' '
		<< (void*)vptr[1] << endl;
	vptr[0] (&a);
	vptr[1] (&a);
	vptr = *(VPTR*)&b;
	cout << "B之虚表指针：" << vptr << endl;
	cout << (void*)vptr[0] << ' '
		<< (void*)vptr[1] << endl;
	vptr[0] (&b);
	vptr[1] (&b);
	return 0;
}
