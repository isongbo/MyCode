#include <errno.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <stdexcept>
using namespace std;
class FileException : public exception {
public:
	FileException (void) :
		m_msg (strerror (errno)) {}
	const char* what (void) const throw () {
		return m_msg.c_str ();
	}
	~FileException (void) throw () {}
private:
	string m_msg;
};
void foo (void) {
	char* p = new char[/*0xFFFFFFFF*/1];
	FILE* fp = fopen ("none", "r");
	if (! fp) {
		delete[] p;
		throw FileException ();
	}
	// ...
	fclose (fp);
	delete[] p;
}
int main (void) {
	try {
		foo ();
	}
	catch (bad_alloc& ex) {
		cout << "处理内存分配失败..." << endl;
		return -1;
	}
	catch (FileException& ex) {
		cout << "处理文件访问失败..." << endl;
		return -1;
	}
	catch (exception& ex) {
		cout << "系统错误，请联系系统管理员..."
			<< endl;
		cout << ex.what () << endl;
		return -1;
	}
	catch (...) {
	}
	return 0;
}
