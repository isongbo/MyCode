#include <cstdio>
#include <iostream>
using namespace std;
class A {
public:
	A (size_t size) : m_data (new int[size]) {
		FILE* fp = fopen ("none", "r");
		if (! fp) {
			cout << "释放内存资源" << endl;
			delete[] m_data;
			throw -1;
		}
		// ...
		fclose (fp);
	}
	~A (void) {
		if (m_data) {
			cout << "释放内存资源" << endl;
			delete[] m_data;
			m_data = NULL;
		}
	}
private:
	int* m_data;
};
int main (void) {
	try {
		A a (1024);
		// ...
	}
	catch (int& ex) {
		cout << ex << endl;
		return -1;
	}
	return 0;
}
