#include <cstdlib>
#include <cstdio>
#include <errno.h>
#include <cstring>
#include <iostream>
using namespace std;
class CalcException {
public:
	CalcException (string const& msg,
		string const& file, string const& func,
		int no) : m_msg (msg), m_file (file),
		m_func (func), m_no (no) {}
	friend ostream& operator<< (ostream& os,
		CalcException const& ex) {
		return os << ex.m_msg << "："
			<< ex.m_file << "，"
			<< ex.m_func << "，"
			<< ex.m_no;
	}
private:
	string m_msg;
	string m_file;
	string m_func;
	int m_no;
};
void foo (void) {
	// ...
	cout << "要分配内存..." << endl;
	void* p = malloc (/*0xFFFFFFFF*/1);
	if (! p)
		throw 17;
	cout << "分配内存成功！" << endl;
	// ...
	free (p);
	FILE* fp = fopen ("none", "r");
	if (! fp)
		throw string (strerror (errno));
	// ...
	fclose (fp);
	if (0) {
		throw CalcException ("计算错误", __FILE__,
			__FUNCTION__, __LINE__);
	}
	if (1)
		throw 3.14;
}
void bar (void) {
	cout << "调用foo之前..." << endl;
	foo ();
	cout << "调用foo之后..." << endl;
}
void hum (void) {
	try {
		cout << "调用bar之前..." << endl;
		bar ();
		cout << "调用bar之后..." << endl;
	}
	catch (double& ex) {
		cout << ex << endl;
		throw;
	}
}
int main (void) {
	try {
		cout << "调用hum之前..." << endl;
		hum ();
		cout << "调用hum之后..." << endl;
	}
	catch (int& ex) {
		cout << "出错啦：" << ex << endl;
		return -1;
	}
	catch (string& ex) {
		cout << "失败啦：" << ex << endl;
		return -1;
	}
	catch (CalcException& ex) {
		cout << ex << endl;
		return -1;
	}
	catch (...) {
		cout << "其它异常！" << endl;
		return -1;
	}
	return 0;
};
