#include <iostream>
using namespace std;
class A {
public:
	A (void) : m_x (0) {
		cout << "A缺省构造" << endl;
	}
	A (int x) : m_x (x) {
		cout << "A有参构造" << endl;
	}
	A (A const& that) : m_x (that.m_x) {
		cout << "A拷贝构造" << endl;
	}
	A& operator= (A const& rhs) {
		cout << "A拷贝赋值" << endl;
		m_x = rhs.m_x;
		return *this;
	}
	~A (void) {
		cout << "A析构函数" << endl;
	}
	friend ostream& operator<< (ostream& lhs,
		A const& rhs) {
		return lhs << rhs.m_x;
	}
private:
	int m_x;
};
class B : public A {
public:
	B (void) : /*A (), */m_y (0) {
		cout << "B缺省构造" << endl;
	}
	B (int x, int y) : A (x), m_y (y) {
		cout << "B有参构造" << endl;
	}
	B (B const& that) : A (that), m_y (that.m_y) {
		cout << "B拷贝构造" << endl;
	}
	B& operator= (B const& rhs) {
		cout << "B拷贝赋值" << endl;
		A::operator= (rhs);
		m_y = rhs.m_y;
		return *this;
	}
	~B (void) {
		cout << "B析构函数" << endl;
	}
	friend ostream& operator<< (ostream& lhs,
		B const& rhs) {
		return lhs << static_cast<A const&> (rhs)
			<< '+' << rhs.m_y << 'i';
	}
private:
	int m_y;
};
int main (void) {
	cout << "-------- 1 --------" << endl;
	B b1 (100, 200);
	cout << "-------- 2 --------" << endl;
	B b2 = b1;
	cout << "-------- 3 --------" << endl;
	B b3;
	b3 = b2;
	cout << "-------- 4 --------" << endl;
	cout << b3 << endl;
	cout << "-------- 5 --------" << endl;
	A* p = new B;
	delete p; // A::~A
	cout << "-------- 6 --------" << endl;
	return 0;
}
