#include <iostream>
using namespace std;
class A {
public:
	int m_pub;
	void pub (void) { cout << "pub" << endl; }
protected:
	int m_pro;
	void pro (void) { cout << "pro" << endl;
		m_pri = 100;
		cout << m_pri << endl;
	}
private:
	int m_pri;
	void pri (void) { cout << "pri" << endl; }
};
class B : public A {
public:
	void foo (void) {
		m_pub = 0;
		pub ();
		m_pro = 0;
		pro ();
//		m_pri = 0;
//		pri ();
	}
};
int main (void) {
	B b;
	b.m_pub = 1;
	b.pub ();
//	b.m_pro = 1;
//	b.pro ();
//	b.m_pri = 1;
//	b.pri ();
	cout << sizeof (b) << endl;
	b.foo ();
	return 0;
}
