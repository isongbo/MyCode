#include <iostream>
using namespace std;
// 人类
class Human {
public:
	Human (string const& name = "", int age = 0) :
		m_name (name), m_age (age) {}
	void eat (string const& food) const {
		cout << m_name << "吃" << food << endl;
	}
	void sleep (int hours) const {
		cout << m_name << "睡" << hours << "小时"
			<< endl;
	}
	void old (void) const {
		cout << "我今年" << m_age << "岁" << endl;
	}
protected:
	string m_name;
	int m_age;
};
// 学生类
class Student : public Human {
public:
	Student (string const& name, int age, int no) :
		Human (name, age), m_no (no) {}
	void learn (string const& course) const {
		cout << "我的学号" << m_no << "，正在学习"
			<< course << endl;
	}
private:
	int m_no;
};
// 教师类
class Teacher : public Human {
public:
	Teacher (string const& name, int age,
		double salary) : Human (name, age),
		m_salary (salary) {}
	void teach (string const& course) const {
		cout << "我的工资" << m_salary
			<< "，正在讲授" << course << endl;
	}
private:
	double m_salary;
};
int main (void) {
	Student s1 ("张飞", 25, 1001);
	s1.eat ("包子");
	s1.sleep (5);
	s1.old ();
	s1.learn ("C++");
	cout << sizeof (s1) << endl;
	Teacher t1 ("曹操", 60, 50000);
	t1.eat ("煎饼");
	t1.sleep (2);
	t1.old ();
	t1.teach ("标C");
	cout << sizeof (t1) << endl;
	Human* h = &s1; // 向上造型安全，皆然性
	h->eat ("KFC");
	h->sleep (10);
	h->old ();
//	h->learn ("UNIX");
	Student* s = static_cast<Student*> (h);
	s->learn ("UNIX");
	Human h1 ("刘备", 40);
	s = static_cast<Student*> (&h1);
	s->learn ("Win32");
	return 0;
}
