#include <iostream>
using namespace std;
class X {
public:
	int m_pub;
protected:
	int m_pro;
private:
	int m_pri;
};
class Y1 : public X { // 公子
};
class Z1 : public Y1 {
public:
	void foo (void) {
		m_pub = 0;
		m_pro = 0;
//		m_pri = 0;
	}
};
class Y2 : protected X { // 保子
};
class Z2 : public Y2 {
public:
	void foo (void) {
		m_pub = 0;
		m_pro = 0;
//		m_pri = 0;
	}
};
class Y3 : private X { // 私子
};
class Z3 : public Y3 {
public:
	void foo (void) {
//		m_pub = 0;
//		m_pro = 0;
//		m_pri = 0;
	}
};
int main (void) {
	Y1 y1;
	y1.m_pub = 0;
//	y1.m_pro = 0;
//	y1.m_pri = 0;
	Y2 y2;
//	y2.m_pub = 0;
//	y2.m_pro = 0;
//	y2.m_pri = 0;
	Y3 y3;
//	y3.m_pub = 0;
//	y3.m_pro = 0;
//	y3.m_pri = 0;
	X* x = &y1;
//	x = &y2;
//	x = &y3;
	return 0;
}
