#include <iostream>
using namespace std;
class A {
public:
	A (int data) : m_data (data) {}
protected:
	int m_data;
};
class B : virtual public A {
public:
	B (int data) : A (data) {}
	void set (int data) {
		m_data = data;
	}
};
class C : virtual public A {
public:
	C (int data) : A (data) {}
	int get (void) {
		return m_data;
	}
};
class D : public B, public C {
public:
	D (int data) : B (-9), C (23), A (data) {}
};
int main (void) {
	D d (1000);
	cout << d.get () << endl;
	d.set (2000);
	cout << d.get () << endl;
	cout << sizeof (D) << endl; // 12
	cout << sizeof (B) << endl; // 
	cout << sizeof (C) << endl; // 
	cout << sizeof (A) << endl; // 
	return 0;
}
