#include <iostream>
using namespace std;
class A {
public:
	void foo (void) {
		cout << "A::foo" << endl;
	}
	void bar (void) {}
	int hum;
};
class B : public A {
public:
	using A::foo;
	void foo (int x) {
		cout << "B::foo" << endl;
		A::hum = 10;
	}
	int bar;
	typedef unsigned int hum;
};
int main (void) {
	B b;
//	b.A::foo ();
	b.foo ();
	b.foo (100);
	b.A::bar ();
	b.A::hum = 10;
	return 0;
}
