#include <iostream>
using namespace std;
class Phone {
public:
	Phone (string const& no) : m_no (no) {}
	void call (string const& no) const {
		cout << m_no << "打电话给" << no << endl;
	}
	int m_a;
	int foo (int x, int y) const {
		return x + y;
	}
private:
	string m_no;
};
class Player {
public:
	Player (string const& media) :
		m_media (media) {}
	void play (string const& clip) const {
		cout << m_media << "播放器播放" << clip
			<< endl;
	}
	typedef int m_a;
	int foo (int x, int y, int z) const {
		return x + y + z;
	}
private:
	string m_media;
};
class Computer {
public:
	Computer (string const& os) : m_os (os) {}
	void run (string const& app) const {
		cout << "在" << m_os << "系统上运行"
			<< app << endl;
	}
	void m_a (void) {}
private:
	string m_os;
};
class SmartPhone : public Phone, public Player,
	public Computer {
public:
	SmartPhone (string const& no,
		string const& media, string const os) :
		Phone (no), Player (media), Computer (os) {}
	int m_a;
	using Phone::foo;
	using Player::foo;
};
int main (void) {
	SmartPhone sp ("13910110072", "MP4", "iOS");
	sp.call ("01062332018");
	sp.play ("小苹果");
	sp.run ("LOL");
	Phone* phone = &sp;
//	Player* player = reinterpret_cast<Player*>(&sp);
	Player* player = &sp;
	Computer* computer = &sp;
	cout << &sp << ' ' << phone << ' ' << player
		<< ' ' << computer << endl;
	phone->call ("01062332018");
	player->play ("小苹果");
	computer->run ("LOL");
	SmartPhone* psp =
		static_cast<SmartPhone*> (player);
	cout << psp << endl;
	psp = static_cast<SmartPhone*> (computer);
	cout << psp << endl;
	sp.Phone::m_a = 20;
	SmartPhone::Player::m_a i;
	sp.m_a = 10;
	sp.Computer::m_a ();
//	cout << sp.Phone::foo (100, 200) << endl;
//	cout << sp.Player::foo (100, 200, 300) << endl;
	cout << sp.foo (100, 200) << endl;
	cout << sp.foo (100, 200, 300) << endl;
	return 0;
}
