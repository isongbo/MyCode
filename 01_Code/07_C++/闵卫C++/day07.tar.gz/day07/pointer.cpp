#include <iostream>
using namespace std;
class B {
public:
	B (void) : m_data (1234) {}
	void foo (void) {
		cout << "B::foo" << endl;
	}
	string operator() (string const& x = "我在吃", 
		string const& y = "好吃的") const {
		return x + y;
	}
	int m_data;
};
class A {
public:
	A (B* b) : m_b (b) {}
	B* operator-> (void) const {
		return m_b;
	}
	B& operator* (void) const {
		return *m_b;
	}
private:
	B* m_b;
};
int main (void) {
	B b;
	A a (&b);
	cout << a->m_data << endl;
//	cout << a.operator->()->m_data << endl;
	a->foo ();
//	a.operator->()->foo ();
	cout << (*a).m_data << endl;
//	cout << a.operator*().m_data << endl;
	(*a).foo ();
//	a.operator*().foo ();
	cout << b ("我在学习", "标准C++编程") << endl;
//	cout << b.operator() (
//		"我在学习", "标准C++编程") << endl;
	cout << b () << endl;
	return 0;
}
