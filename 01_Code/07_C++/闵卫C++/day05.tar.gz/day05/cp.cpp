#include <iostream>
using namespace std;
class Integer {
public:
	Integer (int i) : m_i (new int (i)) {}
	/* 缺省的支持浅拷贝的拷贝构造函数
	Integer (Integer const& that) :
		m_i (that.m_i) {}
	*/
	// 自定义支持深拷贝的拷贝构造函数
	Integer (Integer const& that) :
		m_i (new int (*that.m_i)) {}
	~Integer (void) {
		if (m_i) {
			delete m_i;
			m_i = NULL;
		}
	}
	/* 缺省的支持浅拷贝的拷贝赋值运算符函数
	Integer& operator= (Integer const& rhs) {
		cout << "拷贝赋值运算符函数" << endl;
		m_i = rhs.m_i;
	}
	*/
	// 自定义支持深拷贝的拷贝赋值运算符函数
	Integer& operator= (Integer const& rhs) {
		if (&rhs != this) { // 防止自赋值
			int* i = new int (*rhs.m_i);
			delete m_i; // 释放旧资源
			m_i = i;
			// 分配新资源
			// 拷贝新内容
		}
		return *this; // 返回自引用
	}
	int* m_i;
};
int main (void) {
	Integer i1 (100);
	cout << *i1.m_i << endl;
	Integer i2 = i1; // 拷贝构造
	cout << *i2.m_i << endl;
	*i1.m_i = 200;
	cout << *i2.m_i << endl;
	Integer i3 (300);
	i1 = i3; // 拷贝赋值
//	i1.operator= (i3); // 拷贝赋值运算符函数
	cout << *i1.m_i << endl; // 300
	cout << *i3.m_i << endl; // 300
	*i3.m_i = 400;
	cout << *i1.m_i << endl; // 300
	cout << *i3.m_i << endl; // 400
	cout << i1.m_i << ' ' << i3.m_i << endl;
	int x = 10, y = 20, z = 30;
	(x = y) = z;
	cout << x << ' ' << y << ' ' << z << endl;
	// 30 20 30
	(i1 = i2) = i3;
//	i1.operator= (i2).operator= (i3)
	i1 = i1;
	return 0;
}
