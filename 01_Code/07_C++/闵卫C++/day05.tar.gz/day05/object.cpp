#include <cstring>
#include <iostream>
using namespace std;
class Student {
public:
	Student (char const* name, int age) :
//	Student (Student* this, char const* name,
//		int age)
		m_age (age) {
		cout << "构造函数中的this：" << this
			<< endl;
		strcpy (m_name, name);
	}
	void print (void) {
		cout << "this：" << this << endl;
		cout << m_name << "，" << m_age << endl;
	}
	/*
	void print (Student* this) {
		cout << this->m_name << "，" <<
			this->m_age << endl;
	}
	*/
private:
	char m_name[256];
	int m_age;
};
int main (void) {
	Student s1 ("张飞", 25);
	// s1.Student (&s1, "张飞", 25);
	cout << "&s1：" << &s1 << endl;
	s1.print (); // s1.print (&s1);
	cout << sizeof (s1) << endl;
	Student s2 ("赵云", 20);
	cout << "&s2：" << &s2 << endl;
	s2.print (); // s2.print (&s2);
	return 0;
}
