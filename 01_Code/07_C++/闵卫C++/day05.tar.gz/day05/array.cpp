#include <iostream>
using namespace std;
class Array {
public:
	Array (size_t size) : m_array (new int[size]),
		m_size (size) {
		cout << "构造函数：" << this << endl;
	}
	~Array (void) {
		cout << "析构函数：" << this << endl;
		delete[] m_array;
	}
	int& at (size_t i) {
		if (i >= m_size)
			throw string ("下标溢出！");
		return m_array[i];
	}
	int const& at (size_t i) const {
		return const_cast<Array*> (this)->at (i);
	}
private:
	int* m_array;
	size_t m_size;
};
Array g_a (3);
int main (void) {
	cout << "main函数开始了！" << endl;
	{
		Array a (5);
		for (size_t i = 0; i < 5; ++i)
			a.at (i) = i + 1;
		for (size_t i = 0; i < 5; ++i)
			cout << a.at (i) << ' ';
		cout << endl;
	}
	cout << "再见喽！" << endl;
	Array* a = new Array (10);
//	a = malloc (sizeof (Array));
//	Array::Array (a);
	// ...
	delete a;
//	Array::~Array (a);
//	free (a);
	return 0;
}
