#include <iostream>
using namespace std;
class A {
public:
	void foo (void) {} // 非常函数
//	void foo (A* this) {}
	void bar (void) const {} // 常函数
//	void bar (A const* this) {}
	void hum (void) {
//	void hum (A* this) {
		cout << "hum函数的非常版本" << endl;
	}
	void hum (void) const {
//	void hum (A const* this) {
		cout << "hum函数的常版本" << endl;
	}
	void fun (void) const {
		cout << "fun函数的常版本" << endl;
	}
};
int main (void) {
	A a; // 非常对象
	a.foo (); // foo (&a)
	a.bar (); // bar (&a)
	A const& r = a; // 常对象
//	r.foo (); // foo (&r)
	r.bar (); // bar (&r)
	A const* p = &a; // 常对象
//	p->foo (); // foo (p)
	p->bar (); // bar (p)
	a.hum (); // hum (&a);
	r.hum (); // hum (&r);
	p->hum (); // hum (p);
	a.fun ();
	r.fun ();
	p->fun ();
	return 0;
}
