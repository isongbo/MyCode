#include <iostream>
using namespace std;
class A {
public:
	A (int* data, int numb) : numb (numb) {
		for (int i = 0; i < numb; ++i)
			this->data[i] = data[i];
//		this->numb = numb;
	}
	int data[1024];
	int numb;
};
class B {
public:
	B (void) : m_counter (0) {}
	B& inc (void) {
		++m_counter;
		return *this; // 返回自引用
	}
	int m_counter;
};
int main (void) {
	int data[5] = {10, 20, 30, 40, 50};
	A a (data, 5);
	for (int i = 0; i < a.numb; ++i)
		cout << a.data[i] << ' ';
	cout << endl;
	B b;
	b.inc ().inc ().inc ();
	cout << b.m_counter << endl; // 3
	return 0;
}
