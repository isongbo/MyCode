#include <iostream>
using namespace std;
class A {
public:
	A (void) {
		cout << "A构造" << endl;
	}
	~A (void) {
		cout << "A析构" << endl;
	}
};
class B {
private:
	A m_a;
};
class C {
public:
	C (void) : m_a (new A) {}
	~C (void) {
		delete m_a;
	}
private:
	A* m_a;
};
int main (void) {
//	B b;
	C c;
	return 0;
}
