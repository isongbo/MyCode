#include <iostream>
using namespace std;
class Student {
public:
	Student (string const& name = "", int age = 0) :
		m_name (name), m_age (age), m_times (0) {}
	// 常函数
	void print (void) const {
//	void print (Student const* this) {
		cout << m_name << "，" << m_age << endl;
//		this->m_name = "sb";
//		this->m_age = -1;
//		++const_cast<Student*> (this)->m_times;
		++m_times;
	}
	string m_name;
	int m_age;
	mutable int m_times;
};
void print (Student const& student) {
	cout << student.m_name << "，"
		<< student.m_age << endl;
//	student.m_name = "sb";
//	student.m_age = -1;
}
int main (void) {
	Student student ("张飞", 25);
	print (student);
	print (student);
	student.print ();
	student.print ();
	cout << student.m_times << endl;
	return 0;
}
