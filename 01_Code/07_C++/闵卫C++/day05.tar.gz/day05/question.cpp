#include <iostream>
using namespace std;
class Student;
class Teacher {
public:
	void educate (Student* student);
	void reply (char const* answer) {
		m_answer = answer;
	}
private:
	string m_answer;
};
class Student {
public:
	void ask (char const* question,
		Teacher* teacher) {
		cout << "问题：" << question << endl;
		teacher->reply ("我不知道！");
	}
};
void Teacher::educate (Student* student) {
	student->ask ("什么是this指针？", this);
	cout << "回答：" << m_answer << endl;
}
class A {
public:
	A (void) {
		cout << "我出生了！" << endl;
	}
	~A (void) {
		cout << "我要死了！" << endl;
	}
	void work (void) {
		cout << "我工作了..." << endl;
		delete this; // 自我毁灭
	}
};
int main (void) {
	Teacher t;
	Student s;
	t.educate (&s);
	(new A)->work ();
	return 0;
}
