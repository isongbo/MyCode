#include <cstring>
#include <iostream>
using namespace std;
class String {
public:
	String (char const* str = NULL) :
		m_str (strcpy (
			new char [strlen (str ? str : "") + 1],
			str ? str : "")) {}
	String (String const& that) :
		m_str (strcpy (
			new char [strlen (that.m_str) + 1],
			that.m_str)) {}
	~String (void) {
		if (m_str) {
			delete[] m_str;
			m_str = NULL;
		}
	}
	String& operator= (String const& rhs) {
	}
	char const* c_str (void) const {
		return m_str;
	}
private:
	char* m_str;
};
int main (void) {
	String s1 ("hello");
	cout << s1.c_str () << endl;
	String s2 = s1;
	cout << s2.c_str () << endl;
	String s3 ("world");
	s2 = s3;
	cout << s2.c_str () << endl;
	return 0;
}
