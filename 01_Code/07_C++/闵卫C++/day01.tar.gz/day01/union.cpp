#include <iostream>
#include <cstdio>
using namespace std;
int main (void) {
	union {
		int n;
		char c[4];
	};
	n = 0x12345678;
	for (int i = 0; i < 4; ++i)
		printf ("%#x ", c[i]);
	cout << endl;
	return 0;
}
