#include <iostream>
using namespace std;
enum Color {RED, GREEN, BLUE};
void foo (int n) {}
void bar (Color c) {}
int main (void) {
	cout << RED << ' ' << GREEN << ' ' << BLUE
		<< endl;
//	Color c = 0; // ERROR
	Color c = RED;
	int n = c;
	cout << n << endl;
	foo (RED);
//	bar (0); // ERROR
	return 0;
}
