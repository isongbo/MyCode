#include <iostream>
#include <cstdio>
using namespace std;
int main (void) {
	string s1 = "hello";
	cout << s1 << endl;
	s1 += " ";
	s1 += "world";
	cout << s1 << endl;
	s1 = "达内科技";
	cout << s1 << endl;
	string s2 = "达内";
	cout << (s1 > s2) << endl;
	cout << s1.length () << endl;
	string s3 = "./string.cpp";
	FILE* fp = fopen (s3.c_str (), "r");
	s3[2] = 'S';
	cout << s3 << endl;
	for (size_t i = 0; i < s3.length (); ++i)
		cout << s3[i] << endl;
	return 0;
}
