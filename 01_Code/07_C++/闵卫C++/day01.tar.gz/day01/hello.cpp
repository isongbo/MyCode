#include <iostream>
//#include <stdio.h>
#include <cstdio>
int main (void) {
	std::cout << "Hello, World !" << std::endl;
	printf ("Hello, World !\n");
	int i;
	std::cin >> i;
	std::cerr << i << std::endl;
	std::cout << 10 << ' ' << 1.23 << ' '
		<< "字符串" << std::endl;
	i = 1;
	i = i << 2;
	std::cout << i << std::endl;
	return 0;
}
