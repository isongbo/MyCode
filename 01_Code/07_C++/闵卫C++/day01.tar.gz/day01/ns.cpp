#include <iostream>
using namespace std;
//int var = 9999;
namespace ns {
	int var = 0;
	void fun (void) {
		std::cout << "ns的fun函数" << std::endl;
	}
}
namespace ns {
	struct type {
		int x;
		char y[256];
	};
}
namespace nt {
	void fun (void) {
		std::cout << "nt的fun函数" << std::endl;
	}
}
namespace nu {
	int x = 1234;
	void fun (void) {
		std::cout << "nu的fun函数" << std::endl;
	}
}
int y = 8888;
namespace nv {
	int x = 5678;
	int y = 9999;
	void foo (void) {
		cout << y << endl;
		cout << ::y << endl;
	}
}
namespace ns1 {
	int a = 1;
	namespace ns2 {
		int a = 2;
		namespace ns3 {
			int a = 3;
		}
	}
}
int main (void) {
	std::cout << ns::var << std::endl;
	ns::fun ();
	struct ns::type t = {100, "张飞"};
	std::cout << t.x << ' ' << t.y << std::endl;
	using namespace ns;
	var++;
	std::cout << var << std::endl;
	fun ();
	using namespace nt;
	nt::fun ();
	ns::fun ();
	cout << var << endl;
	using namespace nv;
	using nu::x;
	cout << "### " << x << endl;
	nu::fun ();
//	using nv::x;
	nv::foo ();
	cout << ns1::a << endl;
	cout << ns1::ns2::a << endl;
	cout << ns1::ns2::ns3::a << endl;
	namespace ns123 = ns1::ns2::ns3;
	cout << ns123::a << endl;
	return 0;
}
