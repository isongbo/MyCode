#include <iostream>
using namespace std;
struct Student {
	// 成员变量
	char name[128];
	int age;
	int score;
	// 成员函数
	void who (void) {
		cout << "我是" << name << "，今年"
			<< age << "岁。今天考试得了"
			<< score << "分。" << endl;
	}
};
int main (void) {
	Student s = {"张飞", 25, 85}, *p = &s;
	cout << s.name << ' ' << s.age << ' '
		<< s.score << endl;
	cout << p->name << ' ' << p->age << ' '
		<< p->score << endl;
	s.who ();
	p->who ();
	Student t = {"赵云", 22, 45};
	t.who ();
	return 0;
}
