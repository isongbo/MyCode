#include <iostream>
using namespace std;
int main (void) {
	bool b = true;
	cout << boolalpha << b << endl;
	b = !b;
	cout << b << endl;
	cout << sizeof (b) << endl;
	b = 1000;
	cout << b << endl;
	b = 3.14;
	cout << b << endl;
	b = "hello, world";
	cout << b << endl;
	b = NULL;
	cout << b << endl;
	bool male = true;
	return 0;
}
