#include <iostream>
using namespace std;
class Student {
public:
	/*
	Student (string const& name, int age) {
		m_name = name;
		m_age = age;
	}
	Student (string const& name) {
		m_name = name;
		m_age = 20;
	}
	// 缺省构造函数
	Student (void) {
		m_name = "";
		m_age = 20;
	}
	*/
	Student (string const& name = "", int age=20) {
		m_name = name;
		m_age = age;
	}
	void print (void) {
		cout << m_name << "，" << m_age << endl;
	}
private:
	string m_name;
	int m_age;
};
int main (void) {
//	Student s1 ("张飞", 25);
	Student s1 = Student ("张飞", 25);
	Student s2 ("赵云");
//	Student s3 (); // 被编译器误解为函数声明
	Student s3;
	s1.print ();
	s2.print ();
	s3.print ();
	cout << "----------------" << endl;
	Student* s4 = new Student ("关羽", 40);
	Student* s5 = new Student ("刘备");
	Student* s6 = new Student ();
	Student* s7 = new Student;
	s4->print ();
	s5->print ();
	s6->print ();
	s7->print ();
	delete s7;
	delete s6;
	delete s5;
	delete s4;
	cout << "----------------" << endl;
	Student sa[3];
	for (size_t i = 0; i < 3; ++i)
		sa[i].print ();
	cout << "----------------" << endl;
	Student sc[] = {
		Student ("曹操", 35),
		Student ("孙权"),
		Student ()};
	for (size_t i = 0; i < 3; ++i)
		(sc+i)->print ();
	cout << "----------------" << endl;
	Student* sd = new Student[3];
	for (size_t i = 0; i < 3; ++i)
		i[sd].print ();
	delete[] sd;
	cout << "----------------" << endl;
	Student* se = new Student[3] {
		Student ("黄忠", 50),
		Student ("马超"),
		Student ()};
	for (size_t i = 0; i < 3; ++i)
		se[i].print ();
	delete[] se;
	return 0;
}
