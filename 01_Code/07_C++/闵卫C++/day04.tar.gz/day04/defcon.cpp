#include <iostream>
using namespace std;
class A {
public:
	A (void) {
		cout << "A的缺省构造函数" << endl;
		m_data = 0;
	}
	A (int data) {
		cout << "A的有参构造函数" << endl;
		m_data = data;
	}
	int m_data;
};
class B {
public:
	B (int i = 0) {
		m_i = i;
	}
	int m_i; // 基本类型成员
	A   m_a; // 类类型成员
};
int main (void) {
	B b;
	cout << b.m_i << endl;
	return 0;
}
