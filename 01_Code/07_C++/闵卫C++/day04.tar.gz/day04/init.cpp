#include <iostream>
using namespace std;
class Student {
public:
	Student (string const& name = "",
		int age = 20) : m_name (name), m_age (age) {
	}
	void print (void) {
		cout << m_name << "，" << m_age << endl;
	}
private:
	string m_name;
	int m_age;
};
class A {
public:
	A (int data) : m_data (data) {}
	int m_data;
};
class B {
public:
	B (int data) : m_a (data) {}
	A m_a;
};
int g_x = 5678;
class C {
public:
	C (void) : m_i (1000), m_r (g_x) {}
	int const m_i;
	int& m_r;
};
class D {
public:
	D (string const& str) : m_str (str),
		m_len (str.length ()) {}
	int m_len;
	string m_str;
};
struct Date {
	int year;
	int mon;
	int day;
};
class E {
public:
	E (int a[], Date d) : m_a {a[0], a[1], a[2]},
	  /*m_d {d.year, d.mon, d.day}*/
	  m_d (d) {}
	int m_a[3];
	Date m_d;
};
int main (void) {
	Student s1 ("张飞", 25);
	Student s2 ("赵云");
	Student s3;
	s1.print ();
	s2.print ();
	s3.print ();
	B b (1234);
	cout << b.m_a.m_data << endl;
	C c;
	cout << c.m_i << ' ' << c.m_r << endl;
	D d ("ABCDEFG");
	cout << d.m_len << ' ' << d.m_str << endl;
	int a[3] = {123, 456, 789};
	Date dt = {2015, 1, 8};
	E e (a, dt);
	cout << e.m_a[0] << ' ' << e.m_a[1] << ' '
		<< e.m_a[2] << endl;
	cout << e.m_d.year << '-' << e.m_d.mon << '-'
		<< e.m_d.day << endl;
	return 0;
}
