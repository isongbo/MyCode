// 实现学生类
#include <iostream>
using namespace std;
#include "student.h"
// 构造函数
Student::Student (string const& name, int age,
	int no) {
	cout << "我出生了！呵呵！" << endl;
	m_name = name;
	m_age = age;
	m_no = no;
}
void Student::eat (string const& food) {
	cout << "我叫" << m_name << "，正在吃"
		<< food << endl;
}
void Student::sleep (int time) {
	cout << "我今年" << m_age << "岁，睡了"
		<< time << "小时" << endl;
}
void Student::learn (string const& course) {
	cout << "我的学号是" << m_no << "，现在学"
		<< course << "课" << endl;
}
void Student::setName (string const& name) {
	if (name == "二")
		cout << "拒绝接受不雅的姓名！" << endl;
	else
		m_name = name;
}
void Student::setAge (int age) {
	if (age < 0)
		cout << "拒绝接受非法的年龄！" << endl;
	else
		m_age = age;
}
void Student::setNo (int no) {
	if (no < 0 || 10000 < no)
		cout << "拒绝接受错误的学号！" << endl;
	else
		m_no = no;
}
