#ifndef _STUDENT_H
#define _STUDENT_H
#include <string>
using namespace std;
// 声明学生类
class Student {
public:
	// 构造函数
	Student (string const& name, int age, int no);
	void eat (string const& food);
	void sleep (int time);
	void learn (string const& course);
	void setName (string const& name);
	void setAge (int age);
	void setNo (int no);
private:
	string m_name;
	int m_age;
	int m_no;
};
#endif // _STUDENT_H
