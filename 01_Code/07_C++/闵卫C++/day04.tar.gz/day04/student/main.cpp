#include "student.h"
int main (void) {
	Student s1 ("张飞", 25, 1001);
	s1.setName ("二");
	s1.setAge (-1);
	s1.setNo (1001000);
	s1.eat ("面条");
	s1.sleep (1);
	s1.learn ("C++");
	Student* s2 = new Student ("赵云", 20, 1002);
	s2->eat ("烙饼");
	s2->sleep (2);
	s2->learn ("UNIX-C");
	delete s2;
	return 0;
}
