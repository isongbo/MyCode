#include <iostream>
using namespace std;
class Integer {
public:
	Integer (void) {
		m_data = 0;
	}
	explicit Integer (int data) {
		cout << "Integer类型转换构造函数" << endl;
		m_data = data;
	}
	int m_data;
};
void foo (Integer const& i) {
	cout << i.m_data << endl;
}
Integer bar (void) {
	return static_cast<Integer> (400);
}
int main (void) {
	Integer i;
	cout << i.m_data << endl; // 0
	i = static_cast<Integer> (200);
	cout << i.m_data << endl; // 200
	int x = 300;
	foo (static_cast<Integer> (x));
	cout << bar ().m_data << endl;
	return 0;
}
