#include <iostream>
using namespace std;
class Student {
public:
	// 构造函数
	Student (string const& name, int age, int no) {
		cout << "我出生了！呵呵！" << endl;
		m_name = name;
		m_age = age;
		m_no = no;
	}
	void eat (string const& food) {
		cout << "我叫" << m_name << "，正在吃"
			<< food << endl;
	}
	void sleep (int time) {
		cout << "我今年" << m_age << "岁，睡了"
			<< time << "小时" << endl;
	}
	void learn (string const& course) {
		cout << "我的学号是" << m_no << "，现在学"
			<< course << "课" << endl;
	}
	void setName (string const& name) {
		if (name == "二")
			cout << "拒绝接受不雅的姓名！" << endl;
		else
			m_name = name;
	}
	void setAge (int age) {
		if (age < 0)
			cout << "拒绝接受非法的年龄！" << endl;
		else
			m_age = age;
	}
	void setNo (int no) {
		if (no < 0 || 10000 < no)
			cout << "拒绝接受错误的学号！" << endl;
		else
			m_no = no;
	}
private:
	string m_name;
	int m_age;
	int m_no;
};
int main (void) {
	Student s1 ("张飞", 25, 1001);
	s1.setName ("二");
	s1.setAge (-1);
	s1.setNo (1001000);
	s1.eat ("面条");
	s1.sleep (1);
	s1.learn ("C++");
	Student* s2 = new Student ("赵云", 20, 1002);
	s2->eat ("烙饼");
	s2->sleep (2);
	s2->learn ("UNIX-C");
	delete s2;
	return 0;
}
