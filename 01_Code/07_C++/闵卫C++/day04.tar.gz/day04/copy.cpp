#include <iostream>
using namespace std;
class Point3D {
public:
	Point3D (int x = 0, int y = 0, int z = 0) {
		m_x = x;
		m_y = y;
		m_z = z;
	}
	/*
	Point3D (Point3D const& that) {
		cout << "Point3D拷贝构造函数" << endl;
		m_x = that.m_x;
		m_y = that.m_y;
		m_z = that.m_z;
	}
	*/
	void print (void) {
		cout << "三维点(" << m_x << ',' << m_y
			<< ',' << m_z << ')' << endl;
	}
private:
	int m_x;
	int m_y;
	int m_z;
};
void foo (Point3D p) {
	p.print ();
}
Point3D bar (void) {
	Point3D p (40, 50, 60);
	cout << "bar：" << &p << endl;
	return p;
}
int main (void) {
	Point3D p1 (10, 20, 30);
	p1.print ();
	Point3D p2 = p1;
	p2.print ();
	foo (p2);
	Point3D const& p = bar ();
	cout << "main：" << &p << endl;
	return 0;
}
