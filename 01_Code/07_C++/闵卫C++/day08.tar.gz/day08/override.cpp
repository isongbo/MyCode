#include <iostream>
using namespace std;
/* 全局函数不能是虚函数
virtual void foo (void) {}
*/
class A {
public:
	/* 静态成员函数不能是虚函数
	virtual static void foo (void) {}
	*/
	void foo (void) {
		cout << "A::foo" << endl;
	}
};
class B : public A {
public:
	virtual void foo (void) { // 隐藏A::foo
		cout << "B::foo" << endl;
	}
};
class C : public B {
public:
	void foo (void) { // 覆盖B::foo
		cout << "C::foo" << endl;
	}
};
class D : public C {
public:
	void foo (void) { // 覆盖C::foo
		cout << "D::foo" << endl;
	}
};
class E {
public:
	virtual void foo (void) {}
};
class F : public E {
public:
	virtual void bar (void) {} // 函数名不一致
	virtual void foo (int x) {} // 形参表不一致
	virtual void foo (void) const {} // 常属性不一致
	void foo (void) {} // 覆盖E::foo
};
class X {};
class Y : public X {};
class Z {};
class G {
public:
	virtual void foo (void) {}
	virtual int bar (void) {}
	virtual X hum (void) {}
	virtual /*Y**/X* fun (void) {}
};
class H : public G {
public:
	/*int*/void foo (void) {}
	/*long*/int bar (void) {};
	/*Y*/X hum (void) {}
	/*Z**//*X**/Y* fun (void) {}
};
class I {
public:
	virtual void foo (void) {
		cout << "I::foo" << endl;
	}
};
class J : public I {
private:
	void foo (void) { // 覆盖I::foo
		cout << "J::foo" << endl;
	}
};
int main (void) {
	B b;
	A& a = b;
	a.foo ();
	C c;
	B& rb = c;
	rb.foo ();
	D d;
	B* pb = &d;
	pb->foo ();
	J j;
//	j.foo ();
	I& i = j;
	i.foo ();
	return 0;
}
