#include <iostream>
using namespace std;
class A {
public:
	A (void) { cout << "A构造" << endl; }
	virtual ~A (void) { cout << "A析构" << endl; }
};
class B : public A {
public:
	B (void) { cout << "B构造" << endl; }
	~B (void) { cout << "B析构" << endl; }
};
int main (void) {
//	B* p = new B;
	A* p = new B;
	// ...
	delete p;
	return 0;
};
