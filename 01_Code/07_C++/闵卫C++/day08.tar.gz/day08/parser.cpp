#include <iostream>
using namespace std;
class Text {};
class Rect {};
class Image {};
class Parser {
public:
	void parse (char const* filename) {
		// 解析出文本
		Text text;
		showText (text);
		// 解析出矩形
		Rect rect;
		showRect (rect);
		// 解析出图像
		Image image;
		showImage (image);
		// ...
	}
private:
	virtual void showText (Text const&) = 0;
	virtual void showRect (Rect const&) = 0;
	virtual void showImage (Image const&) = 0;
	// ...
};
class RenderForWindows : public Parser {
private:
	void showText (Text const& text) {
		cout << "显示文本" << endl;
	}
	void showRect (Rect const& rect) {
		cout << "显示矩形" << endl;
	}
	void showImage (Image const& image) {
		cout << "显示图像" << endl;
	}
	// ...
};
/*
class RenderForMac : public Parser { ... };
*/
int main (void) {
	RenderForWindows render;
//	RenderForMac render;
	render.parse ("xxx.pdf");
	return 0;
}
