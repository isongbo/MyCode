#include <iostream>
using namespace std;
class A {
public:
	int foo (int x, int y) {
//		m_data = 10;
		return x + y;
	}
	int m_data;
};
class B : public A {
public:
	int m_memb;
};
int main (void) {
	A* p = NULL;
	cout << p->foo (100, 200) << endl;
	B b;
	p = &b;
	cout << (p->m_data = 100) << endl;
	A a;
	B* pb = static_cast<B*> (&a);
	cout << (pb->m_memb = 200) << endl;
	return 0;
}
