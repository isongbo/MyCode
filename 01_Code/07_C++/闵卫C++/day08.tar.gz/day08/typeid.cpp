#include <iostream>
#include <typeinfo>
#include <cstring>
using namespace std;
class XYZ {};
class A { virtual void foo (void) {} };
class B : public A {};
void bar (A* pa) {
//	if (! strcmp (typeid (*pa).name (), "1A"))
	if (typeid (*pa) == typeid (A))
		cout << "传入的是个A对象" << endl;
	else
//	if (! strcmp (typeid (*pa).name (), "1B"))
	if (typeid (*pa) == typeid (B))
		cout << "传入的是个B对象" << endl;
	else
		cout << "传入的是个怪物" << endl;
}
int main (void) {
	cout << typeid (char).name () << endl;
	cout << typeid (unsigned char).name () << endl;
	cout << typeid (short).name () << endl;
	cout << typeid (unsigned short).name () << endl;
	cout << typeid (int).name () << endl;
	cout << typeid (unsigned int).name () << endl;
	cout << typeid (long).name () << endl;
	cout << typeid (unsigned long).name () << endl;
	cout << typeid (long long).name () << endl;
	cout << typeid (unsigned long long).name ()
		<< endl;
	cout << typeid (float).name () << endl;
	cout << typeid (double).name () << endl;
	cout << typeid (long double).name () << endl;
	cout << typeid (int*****).name () << endl;
	cout << typeid (const char*).name () << endl;
	cout << typeid (char const*).name () << endl;
	cout << typeid (char *const).name () << endl;
	cout << typeid (float[10]).name () << endl;
	cout << typeid (float[10][5]).name () << endl;
	cout << typeid (int* (*) (int*)).name ()
		<< endl;
	cout << typeid (int* (*[10]) (int*)).name ()
		<< endl;
	cout << typeid (XYZ).name () << endl;
	B b;
	A* pa = &b;
	cout << typeid (*pa).name () << endl;
	A a;
	bar (&a);
	bar (&b);
	return 0;
}
