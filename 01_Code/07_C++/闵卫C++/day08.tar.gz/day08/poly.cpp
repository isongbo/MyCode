#include <iostream>
using namespace std;
class A {
public:
	A (void) {
		/*this->*/foo (); // A::foo
	}
	~A (void) {
		/*this->*/foo (); // A::foo
	} 
	virtual void foo (void) {
		cout << "A::foo" << endl;
	}
	void bar (void) {
		/*this->*/foo (); // B::foo
	}
};
class B : public A {
public:
	void foo (void) {
		cout << "B::foo" << endl;
	}
};
int main (void) {
	B b;
//	A a = b;
	A& a = b;
	a.foo ();
	b.bar ();
	return 0;
}
