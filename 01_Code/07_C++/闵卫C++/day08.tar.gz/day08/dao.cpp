#include <iostream>
using namespace std;
class Employee {
public:
	string m_name;
	int m_no;
	int m_age;
	// ...
};
class Dao {
public:
	virtual void insert (
		Employee const& emp) const = 0;
};
class OracleDao : public Dao {
public:
	void insert (Employee const& emp) const {
		cout << "向Oracle数据库插入记录" << endl;
	}
};
class SQLServerDao : public Dao {
public:
	void insert (Employee const& emp) const {
		cout << "向SQLServer数据库插入记录" << endl;
	}
};
void business (Dao const& dao) {
	// 通过Pro*C向Oracle数据库插入一条记录
	// 通过ODBC向SQLServer数据库插入一条记录
	Employee emp;
	// ...
	dao.insert (emp); // 面向抽象编程
}
int main (void) {
//	business (OracleDao ());
	business (SQLServerDao ());
	return 0;
}
