#include <iostream>
using namespace std;
class Shape { // 抽象类
public:
	Shape (int x, int y) : m_x (x), m_y (y) {}
	/*
	virtual void draw (void) const {
		cout << "图形(" << m_x << ',' << m_y << ')'
			<< endl;
	}
	*/
	// 纯虚函数
	virtual void draw (void) const = 0;
protected:
	int m_x;
	int m_y;
};
class Rect : public Shape {
public:
	Rect (int x, int y, int w, int h) :
		Shape (x, y), m_w (w), m_h (h) {}
	void draw (void) const {
		cout << "矩形(" << m_x << ',' << m_y << ','
			<< m_w << ',' << m_h << ')' << endl;
	}
private:
	int m_w;
	int m_h;
};
class Circle : public Shape {
public:
	Circle (int x, int y, int r) :
		Shape (x, y), m_r (r) {}
	void draw (void) const {
		cout << "圆形(" << m_x << ',' << m_y << ','
			<< m_r << ')' << endl;
	}
private:
	int m_r;
};
class Triangle : public Shape {
public:
	void foo (void) {}
};
void render (Shape* shapes[]) {
	for (size_t i = 0; shapes[i]; ++i)
		shapes[i]->draw ();
}
int main (void) {
	Shape* shapes[1024] = {};
	shapes[0] = new Rect (1, 2, 3, 4);
	shapes[1] = new Circle (5, 6, 7);
	shapes[2] = new Circle (8, 9, 10);
	shapes[3] = new Rect (11, 12, 13, 14);
	shapes[4] = new Rect (15, 16, 17, 18);
	render (shapes);
//	Shape shape (1, 2);
//	Triangle* pt = new Triangle;
	return 0;
}
