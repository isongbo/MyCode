#include <iostream>
#include <stdexcept>
using namespace std;
class A {
public:
	virtual void foo (void) {}
};
class B : public A {};
class C : public B {};
class D {};
int main (void) {
	B b;
	A* pa = &b;
	cout << "pa = " << pa << endl;
	// pa实际指向B类对象，转换成功
	B* pb = dynamic_cast<B*> (pa);
	cout << "pb = " << pb << endl;
	// pa没有指向C类对象，转换失败，安全
	C* pc = dynamic_cast<C*> (pa);
	cout << "pc = " << pc << endl;
	try {
		A& ra = b;
		C& rc = dynamic_cast<C&> (ra);
	}
	catch (exception& ex) {
		cout << "转换失败：" << ex.what () << endl;
	}
	// pa没有指向D类对象，转换失败，安全
	D* pd = dynamic_cast<D*> (pa);
	cout << "pd = " << pd << endl;
	// B是A的子类，转换成功
	pb = static_cast<B*> (pa);
	cout << "pb = " << pb << endl;
	// C是A的间接子类，转换成功，危险
	pc = static_cast<C*> (pa);
	cout << "pc = " << pc << endl;
	// D与A没有亲缘关系，转换失败，安全
//	pd = static_cast<D*> (pa);
//	cout << "pd = " << pd << endl;
	// 编译期、运行期都不检查，永远成功，危险
	pb = reinterpret_cast<B*> (pa);
	cout << "pb = " << pb << endl;
	pc = reinterpret_cast<C*> (pa);
	cout << "pc = " << pc << endl;
	pd = reinterpret_cast<D*> (pa);
	cout << "pd = " << pd << endl;
	return 0;
}
