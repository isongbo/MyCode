#include <iostream>
using namespace std;
void swap1 (int x, int y) {
	int z = x;
	x = y;
	y = z;
}
void swap2 (int* x, int* y) {
	int z = *x;
	*x = *y;
	*y = z;
}
void swap3 (int& x, int& y) {
	int z = x;
	x = y;
	y = z;
}
void swapp (char const** x, char const** y) {
	char const* z = *x;
	*x = *y;
	*y = z;
}
void swapr (char const*& x, char const*& y) {
	char const* z = x;
	x = y;
	y = z;
}
int main (void) {
	int x = 100, y = 200;
//	swap1 (x, y);
//	swap2 (&x, &y);
	swap3 (x, y);
	cout << x << ' ' << y << endl;
	char const* p = "hello";
	char const* q = "world";
//	swapp (&p, &q);
	swapr (p, q);
	cout << p << ' ' << q << endl;
	return 0;
}
