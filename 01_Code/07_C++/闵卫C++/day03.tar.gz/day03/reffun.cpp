#include <iostream>
using namespace std;
int add (int x, int y) {
	return x + y;
}
int main (void) {
	// 古典写法
	int (*pfunc) (int, int) = &add;
	cout << (*pfunc) (100, 200) << endl;
	// 现代写法
	int (*pfun2) (int, int) = add;
	cout << pfun2 (100, 200) << endl;
	// 函数引用
	int (&rfunc) (int, int) = add;
	cout << rfunc (100, 200) << endl;
	return 0;
}
