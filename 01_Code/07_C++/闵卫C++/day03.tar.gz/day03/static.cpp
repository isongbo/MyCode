#include <iostream>
using namespace std;
int main (void) {
	short x = 10;
	void* v = &x;
	short* p = static_cast<short*> (v);
//	int* q = static_cast<int*> (p);
	return 0;
}
