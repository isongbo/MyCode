#include <iostream>
using namespace std;
int main (void) {
	char c[] = {0x78, 0x56, 0x34, 0x12};
	int* n = reinterpret_cast<int*> (c);
	cout << hex << showbase << *n << endl;
	double x = 3.14;
	double* p = &x;
	int i = reinterpret_cast<int> (p);
	char* h = reinterpret_cast<char*> (i);
	p = reinterpret_cast<double*> (h);
	cout << *p << endl;
	return 0;
}
