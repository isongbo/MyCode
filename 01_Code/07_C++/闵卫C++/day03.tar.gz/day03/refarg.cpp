#include <cmath>
#include <cstring>
#include <iostream>
using namespace std;
void foo (int a) {
	cout << "foo：" << &a << endl;
	++a;
	cout << "a = " << a << endl; // 124
}
void bar (int& a) {
	cout << "bar：" << &a << endl;
	++a;
	cout << "a = " << a << endl; // 124
}
double rect (double w, double h, double* c,
	double& s) {
	*c = (w + h) * 2;
	s = w * h;
	return sqrt (w * w + h * h);
}
struct Student {
	char name[64];
	char addr[256];
	char mbox[128];
};
void insert (Student const& student) {
	cout << student.name << "，"
		<< student.addr << "，"
		<< student.mbox << endl;
//	strcpy (student.name, "sb");
}
int main (void) {
	int x = 123;
	cout << "main：" << &x << endl;
	foo (x);
	cout << "x = " << x << endl; // 123
	bar (x);
	cout << "x = " << x << endl; // 124
	double w = 3, h = 4, c, s, t;
	t = rect (w, h, &c, s);
	cout << "周长：" << c << endl;
	cout << "面积：" << s << endl;
	cout << "对角线：" << t << endl;
	Student student = {"张飞", "达内科技",
		"zhangfei@tarena.com.cn"};
	insert (student);
	cout << student.name << endl;
	return 0;
}
