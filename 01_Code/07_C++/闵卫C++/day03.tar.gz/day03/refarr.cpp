#include <iostream>
using namespace std;
void foo (int a[12]) {
	cout << sizeof (a) << endl; // 4
}
void bar (int a[]) {
	cout << sizeof (a) << endl; // 4
}
void hum (int* a) {
	cout << sizeof (a) << endl; // 4
}
void fun (int (&a)[12]) {
	cout << sizeof (a) << endl; // 48
}
void fff (int (*a)[12]) {
	cout << sizeof (*a) << endl; // 48
}
int main (void) {
	int a[12];
	cout << sizeof (a) << endl; // 48, a整体
	foo (a); // a首地址
	bar (a); // a首地址
	hum (a); // a首地址
	fun (a); // a整体
	fff (&a);// a整体
	return 0;
}
