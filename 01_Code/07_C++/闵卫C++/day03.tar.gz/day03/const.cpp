#include <iostream>
using namespace std;
int main (void) {
	int volatile const x = 100;
	int& r = const_cast<int&> (x);
//	char& c = const_cast<char&> (x);
//	x = 200;
	r = 200;
	cout << &r << ' ' << (void*)&x << endl;
	cout << r << endl;
	cout << x << endl; // cout << 100 << endl;
	return 0;
}
