#include <iostream>
using namespace std;
struct A {
	int data;
	int& foo (void) {
		return data;
	}
};
int& bar (int& a) {
	return a;
}
int& hum (void) {
	static int n = 123;
	return n;
}
int& fun (void) {
	int m = 456;
	return m;
}
int main (void) {
	A a = {100};
	cout << a.data << endl; // 100
	a.foo () = 200;
	cout << a.data << endl; // 200
	int x;
	bar (x) = 1000;
	cout << x << endl; // 1000
	int& r = hum ();
	cout << r << endl; // 123
	fun ();
	cout << r << endl; // 456
	return 0;
}
