#include <iostream>
using namespace std;
int main (void) {
	int a = 10;
	int& b = a;
	++b;
	cout << a << ' ' << b << endl;
	cout << &a << ' ' << &b << endl;
	int& c = b;
	++c;
	cout << a << ' ' << b << ' ' << c << endl;
	cout << &c << endl;
//	int const& d = a;
	const int& d = a;
	cout << d << endl;
	cout << &d << endl;
//	d = 20;
//	d++;
	a = 20;
	b++;
	--c;
	cout << d << endl;
//	int& e = 10;
	int x = 100, y = 200, z = 300;
	cout << x + y + z << endl;
//	x + y = z;
	int const& e = x + y;
	cout << e << endl;
	int const& f = 10;
	cout << f << endl;
//	int& g; // ERROR
	int& g = *new int (100);
	cout << g << endl; // 100
	delete &g;
//	此时g就是一个野引用
	return 0;
}
