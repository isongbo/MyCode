#include <iostream>
using namespace std;
// 单例模式
class A {
public:
	void work (void) {
		cout << "使用对象的功能..." << endl;
	}
	static A& getInstance (void) {
//		return m_a;
		if (! m_a)
			m_a = new A;
		return *m_a;
	}
private:
	A (void) {};
	A (const A&) {};
//	static A m_a;
	static A* m_a;
};
//A A::m_a;
A* A::m_a = NULL;
/*
A g_a;
A g_b;
A g_c;
*/
int main (void) {
	A& a = A::getInstance ();
	a.work ();
	A& b = A::getInstance ();
	b.work ();
	cout << &a << ' ' << &b << endl;
	return 0;
}
