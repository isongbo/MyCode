#include <cstring>
#include <iostream>
using namespace std;
class String {
public:
	String (char const* str = NULL) :
		m_str (strcpy (
			new char [strlen (str ? str : "") + 1],
			str ? str : "")) {}
	String (String const& that) :
		m_str (strcpy (
			new char [strlen (that.m_str) + 1],
			that.m_str)) {}
	~String (void) {
		if (m_str) {
			delete[] m_str;
			m_str = NULL;
		}
	}
	/* 菜鸟
	void operator= (String const& rhs) {
		m_str = new char[strlen (rhs.m_str) + 1];
		strcpy (m_str, rhs.m_str);
	}*/
	/* 小鸟
	String& operator= (String const& rhs) {
		if (&rhs != this) {
			delete[] m_str;
			m_str = strcpy (
				new char[strlen (rhs.m_str) + 1],
				rhs.m_str);
		}
		return *this;
	}*/
	/* 大鸟
	String& operator= (String const& rhs) {
		if (&rhs != this) {
			char* str =
				new char[strlen (rhs.m_str) + 1];
			delete[] m_str;
			m_str = strcpy (str, rhs.m_str);
		}
		return *this;
	}*/
	// 老鸟
	String& operator= (String const& rhs) {
		if (&rhs != this) {
			String str (rhs);
			swap (m_str, str.m_str);
		}
		return *this;
	}
	char const* c_str (void) const {
		return m_str;
	}
private:
	char* m_str;
};
int main (void) {
	String s1 ("hello");
	cout << s1.c_str () << endl;
	String s2 = s1;
	cout << s2.c_str () << endl;
	String s3 ("world");
	s2 = s3;
	cout << s2.c_str () << endl;
	return 0;
}
