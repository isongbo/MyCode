#include <iostream>
using namespace std;
class Complex {
public:
	Complex (int r = 0, int i = 0) :
		m_r (r), m_i (i) {}
	void show (void) const {
		cout << m_r << '+' << m_i << 'i' << endl;
	}
	// 成员函数形式的前++
	Complex& operator++ (void) {
		++m_r;
		++m_i;
		return *this;
	}
	// 全局函数形式的前--
	friend Complex& operator-- (Complex& opd) {
		--opd.m_r;
		--opd.m_i;
		return opd;
	}
	// 成员函数形式的后++
	Complex const operator++ (int) {
		Complex old = *this;
		++*this;
		return old;
	}
	// 全局函数形式的后--
	friend Complex const operator-- (Complex& opd,
		int) {
		Complex old = opd;
		--opd;
		return old;
	}
	friend ostream& operator<< (ostream& lhs,
		Complex const& rhs) {
		return lhs << rhs.m_r << '+' << rhs.m_i
			<< 'i';
	}
private:
	int m_r, m_i;
};
int main (void) {
	int x = 10;
	++x = 20;
	cout << x << endl; // 20
	++++++++x; // ++(++(++(++x)))
	cout << x << endl; // 24
	cout << ++x << endl; // 25
	cout << x << endl; // 25
	Complex c1 (1, 2), c2 (30, 40);
	cout << ++c1 << endl; // 2+3i
//	cout << c1.operator++ () << endl;
	cout << c1 << endl; // 2+3i
	++c1 = c2;
	cout << c1 << endl; // 30+40i
	++++++++c1;
	cout << c1 << endl; // 34+44i
	cout << --c1 << endl; // 33+43i
	cout << c1 << endl; // 33+43i
	------c1;
	cout << c1 << endl; // 30+40i
//	x++ = 30;
//	x++++++++;
	cout << c1++ << endl; // 30+40i
//	cout << c1.operator++ (0) << endl;
	cout << c1 << endl; // 31+41i
	cout << c1-- << endl; // 31+41i
	cout << c1 << endl; // 30+40i
	return 0;
}
