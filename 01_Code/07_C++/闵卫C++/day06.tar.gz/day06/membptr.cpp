#include <cstring>
#include <iostream>
using namespace std;
class Student {
public:
	Student (string const& name = "", int age = 0) :
		m_name (name), m_age (age) {}
	void who (void) const {
		cout << m_name << "，" << m_age << endl;
	}
	bool m_sex;
	double m_score;
	string m_name;
	int m_age;
};
int main (void) {
	string Student::*pname = &Student::m_name;
	int Student::*page = &Student::m_age;
	Student s ("张飞", 25), *p = &s;
	// .* - 成员指针解引用运算符
	cout << s.*pname << "，" << s.*page << endl;
	// ->* - 间接成员指针解引用运算符
	cout << p->*pname << "，" << p->*page << endl;
	int i;
	memcpy (&i, &pname, 4);
	cout << i << endl;
	memcpy (&i, &page, 4);
	cout << i << endl;
	void (Student::*pwho) (void) const =
		&Student::who;
	memcpy (&i, &pwho, 4);
	cout << hex << showbase << i << endl;
	(s.*pwho) ();
	(p->*pwho) ();
	return 0;
}
