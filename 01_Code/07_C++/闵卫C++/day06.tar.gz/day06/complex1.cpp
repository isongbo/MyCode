#include <iostream>
using namespace std;
class Complex {
public:
	Complex (int r = 0, int i = 0) :
		m_r (r), m_i (i) {}
	void show (void) const {
		cout << m_r << '+' << m_i << 'i' << endl;
	}
	// 第一个const：返回常对象，禁止对返回值赋值
	// 第二个const：支持常对象形式的右操作数
	// 第三个const：支持常对象形式的左操作数
	Complex const operator+ (
		Complex const& rhs) const {
		return Complex (m_r + rhs.m_r,
			m_i + rhs.m_i);
	}
private:
	int m_r;
	int m_i;
	friend Complex const operator- (
		Complex const&, Complex const&);
};
Complex const operator- (Complex const& lhs,
	Complex const& rhs) {
	return Complex (lhs.m_r - rhs.m_r,
		lhs.m_i - rhs.m_i);
}
int main (void) {
	Complex c1 (1, 2), c2 (3, 4), c3 (5, 6);
	c1.show ();
	c2.show ();
	c3.show ();
//	Complex c4 = c1.operator+ (c2).operator+ (c3);
	Complex c4 = c1 + c2 + c3;
	c4.show ();
	/*
	int a, b, c;
	(a + b) = c;
	*/
//	(c1 + c2) = c3;
	Complex const c5 (7, 8);
	(c1 + c5).show (); // c1.operator+ (c5)
	(c5 + c1).show (); // c5.operator+ (c1)
	c4 = c3 - c2;
//	c4 = ::operator- (c3, c2);
	c4.show ();
	return 0;
}
