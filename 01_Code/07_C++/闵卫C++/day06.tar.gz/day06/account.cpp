#include <iostream>
using namespace std;
class Account {
public:
	Account (double balance) :
		m_balance (balance) {}
	double settle (void) {
		return m_balance *= (1 + m_inter);
	}
	static void setInter (double inter) {
		m_inter = inter;
	}
private:
	double m_balance;
	static double m_inter;
};
double Account::m_inter = 0.01;
int main (void) {
	Account a1 (1000), a2 (10000);
	cout << a1.settle () << ' '
		<< a2.settle () << endl;
	Account::setInter (0.05);
	cout << a1.settle () << ' '
		<< a2.settle () << endl;
	return 0;
}
