#include <iostream>
using namespace std;
class A {
public:
	int& operator[] (int i) {
		return m_array[i];
	}
	int const& operator[] (int i) const {
		return const_cast<A&> (*this)[i];
	}
private:
	int m_array[10];
};
class B {
public:
	int operator() (int x, int y) const {
		return x + y;
	}
};
class Integer {
public:
	Integer (int i = 0) : m_i (i) {}
	operator int (void) const {
		return m_i;
	}
	int m_i;
};
int main (void) {
	A a;
	a[0] = 1; // a.operator[] (0) = 1
	a[1] = 2; // a.operator[] (1) = 2
	cout << a[0] << ' ' << a[1] << endl;
	A const& cr = a;
	cout << cr[0] << endl;
//	cr[0]++;
	B b;
	cout << b (123, 456) << endl;
//	cout << b.operator() (123, 456) << endl;
	Integer x;
	x = 123;
	cout << x.m_i << endl;
	int y;
	y = x;
	cout << y << endl;
	return 0;
}
