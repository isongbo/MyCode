#include <cmath>
#include <iostream>
using namespace std;
class Complex {
public:
	Complex (int r = 0, int i = 0) :
		m_r (r), m_i (i) {}
	Complex const operator- () const {
		return Complex (-m_r, -m_i);
	}
	friend int operator~ (Complex const& opd) {
		return sqrt (opd.m_r * opd.m_r +
			opd.m_i * opd.m_i);
	}
	friend istream& operator>> (istream& lhs,
		Complex& rhs) {
		return lhs >> rhs.m_r >> rhs.m_i;
	}
	friend ostream& operator<< (ostream& lhs,
		Complex const& rhs) {
		return lhs << rhs.m_r << '+' << rhs.m_i
			<< 'i';
	}
private:
	int m_r, m_i;
};
int main (void) {
	Complex c1, c2;
	cin >> c1 >> c2;
//	::operator>> (::operator>> (cin, c1), c2);
	cout << c1 << ' ' << c2 << endl;
//	::operator<< (
//		::operator<< (
//			::operator<< (
//				::operator<< (cout, c1), ' '), c2),
//					endl);
	cout << -c1 << endl;
	cout << ~c2 << endl;
	return 0;
}

