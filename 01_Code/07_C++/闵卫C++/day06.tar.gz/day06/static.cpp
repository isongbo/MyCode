#include <iostream>
using namespace std;
static int g = 100; // 静态全局变量
static void foo (void) { // 静态全局函数
	static int i = 10; // 静态局部变量
	int j = 10;
	cout << ++i << ' ' << ++j << endl;
}
class A {
public:
	A (void) : m_memb (300) {}
	static int m_smemb; // 静态成员变量
	int m_memb;
	static void foo (void) { // 静态成员函数
		cout << m_smemb << endl;
//		cout << m_memb << endl; // 错误
//		cout << this << endl; // 错误
//		bar (); // 错误
	}
	void bar (void) {
		cout << m_memb << endl;
		cout << m_smemb << endl;
		foo ();
	}
private:
	static int m_spriv;
	static int const m_i = 10; // 只有常静态成员变量
	                           // 才能在类的声明部分
	                           // 初始化
};
int A::m_smemb = 200; // 定义静态成员变量
int A::m_spriv = 400;
int main (void) {
	foo (); // 11 11
	foo (); // 12 11
	foo (); // 13 11
	A a1, a2;
	cout << &a1.m_smemb << ' ' << &a1.m_memb<<endl;
	cout << &a2.m_smemb << ' ' << &a2.m_memb<<endl;
	++a1.m_smemb;
	cout << a2.m_smemb << endl; // 201
	++a1.m_memb;
	cout << a2.m_memb << endl; // 300
	cout << A::m_smemb << endl; // 201
//	cout << A::m_memb << endl; // 错误
//	cout << a1.m_spriv << endl;// 私有无法访问
//	cout << A::m_spriv << endl;
	return 0;
}
