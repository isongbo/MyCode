#ifndef _ADD_H
#define _ADD_H
#ifdef __cplusplus
extern "C" {
#endif
int add (int, int);
#ifdef __cplusplus
}
#endif
#endif // _ADD_H
