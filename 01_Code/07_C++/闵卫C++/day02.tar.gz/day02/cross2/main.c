#include <stdio.h>
#include "add.h"
int main (void) {
	printf ("计算结果：%d\n", add (100, 200));
	return 0;
}
