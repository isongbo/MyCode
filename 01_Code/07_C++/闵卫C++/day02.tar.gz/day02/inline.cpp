#include <iostream>
using namespace std;
inline double square (double x) {
	return x * x;
}
int main (void) {
	cout << square (3.0) << endl;
//	cout << 3.0 * 3.0 << endl;
	return 0;
}
