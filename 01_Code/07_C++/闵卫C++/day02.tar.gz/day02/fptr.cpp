#include <iostream>
using namespace std;
double foo (int n) {
	cout << 1 << endl;
}
char* foo (float f) {
	cout << 2 << endl;
}
int main (void) {
	double (*p1) (int) = foo;
	char* (*p2) (float) = foo;
	cout << (void*)p1 << ' ' << (void*)p2 << endl;
	p1 (3.14f); // 1
	p2 (10); // 2
	foo (3.14f); // 2
	foo (10); // 1
	return 0;
}
