#include <iostream>
using namespace std;
void funa (char* p) {
	cout << 1 << endl;
}
void funa (char const* p) {
	cout << 2 << endl;
}
void funb (char const* p, char c) {
	cout << 1 << endl;
}
void funb (char*p, int n) {
	cout << 2 << endl;
}
void func (char c) {
	cout << 1 << endl;
}
void func (int n) {
	cout << 2 << endl;
}
void func (long l) {
	cout << 3 << endl;
}
void fund (int n, void* p) {
	cout << 1 << endl;
}
void fund (double d, ...) {
	cout << 2 << endl;
}
int main (void) {
	char* p;
	funa (p); // 完全匹配优于常量转换
	char c;
	funb (p, c); // 常量转换优于升级转换
	short h;
	func (h); // 升级转换优于标准转换
	          // 但也没有必要过分升级
	double d;
	void* pv;
	fund (d, pv); // 可变长参数表匹配度最低
	return 0;
}
