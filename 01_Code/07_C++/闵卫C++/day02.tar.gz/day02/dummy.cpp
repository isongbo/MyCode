#include <iostream>
using namespace std;
int add (int a, int, int c) {
	return a + c;
}
void foo (int) {}
void bar (void) {}
void bar (int) {}
int main (void) {
	cout << add (100, 200, 300) << endl;
	return 0;
}
