#include <iostream>
using namespace std;
void foo (void) {
	cout << "1" << endl;
}
void foo (int n) {
	cout << "2" << endl;
}
void foo (int* n) {
	cout << "3" << endl;
}
void foo (int n, double d) {
	cout << "4" << endl;
}
void foo (double n, int d) {
	cout << "5" << endl;
}
//void foo (double d, int n) {} // ->15
//int foo (void) {} // ->3
int main (void) {
	foo (); // 1
	foo (100); // 2
	int n;
	foo (&n); // 3
	foo (n, 1.13); // 4
	foo (1.13, n); // 5
	return 0;
}
