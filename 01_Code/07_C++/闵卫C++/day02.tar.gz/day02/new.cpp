#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
int main (void) {
//	int* p = (int*)malloc (sizeof (int));
	int* p = new int;
	*p = 1234;
	cout << *p << endl;
//	free (p);
	delete p;
	p = new int (); // 用0初始化
	cout << *p << endl;
	delete p;
	p = new int (5678); // 指定初始值
	cout << *p << endl;
	delete p;
	p = NULL;
	delete p;
//	p = (int*)malloc (5 * sizeof (int));
	p = new int[5] {10, 20, 30, 40, 50}; // C++11
	/*
	for (int i = 0; i < 5; ++i)
		p[i] = (i+1)*10;
	*/
	for (int i = 0; i < 5; ++i)
		cout << p[i] << ' ';
	cout << endl;
	delete[] p; // !!!
	int (*prow)[4] = new int[3][4];
//	int *prow[4]
	for (int i = 0; i < 3; ++i)
		for (int j = 0; j < 4; ++j)
			prow[i][j] = (i+1)*10+(j+1);
	for (int i = 0; i < 3; ++i) {
		for (int j = 0; j < 4; ++j)
			cout << prow[i][j] << ' ';
		cout << endl;
	}
	delete[] prow;
	int (*ppage)[4][5] = new int[3][4][5];
//	int (*ppage)[4][5] =
//		(int (*)[4][5])malloc (60 * sizeof (int));
	delete[] ppage;
	try {
		p = new int[0xFFFFFFFF];
		// ...
		delete[] p;
	}
	catch (exception& ex) {
		cout << ex.what () << endl;
		perror ("new");
//		return -1;
	}
//	char* pool = new char[1024]; // 分配内存池
	char pool[1024];
	int* pn = new (pool) int (123); // 定位分配
	char* ps = new (pool+4) char[15];
	strcpy (ps, "Hello, World !");
	double* pd = new (pool+19) double (3.14);
	cout << *pn << ' ' << ps << ' ' << *pd
		<< endl;
//	delete[] pool; // 释放内存池
	return 0;
}
