#include <iostream>
using namespace std;
void foo (int a, int b = 1000) {
	cout << a << ' ' << b << endl;
}
void bar (int a = 100+900) {
	cout << a << endl;
}
int b = 1000;
void hum (int a = b) {
	cout << a << endl;
}
//void fun (int a, int b = a) {} // ERROR
void fun (int a = 1000);
void fff (int a, int b = 1000, int c = 2000) {
	cout << a << ' ' << b << ' ' << c << endl;
}
void fff (int a) {
	cout << a << endl;
}
int main (void) {
	foo (123, 456);
	foo (123); // foo (123, 1000);
	bar (); // bar (1000);
	hum ();
	fun ();
	fff (123, 456);
//	fff (123, , 456);
//	fff (123); // ERROR
	return 0;
}
void fun (int a /* = 1000 */) {
	cout << a << endl;
}
