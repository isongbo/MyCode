#include <iostream>
using namespace std;
extern "C" {
#include "add.h"
}
int main (void) {
	cout << add (100, 200) << endl;
	return 0;
}
