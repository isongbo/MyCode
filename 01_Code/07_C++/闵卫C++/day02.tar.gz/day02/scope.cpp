#include <iostream>
using namespace std;
void foo (void) { cout << 1 << endl; }
namespace ns1 {
	void foo (int a) { cout << 2 << endl; }
	namespace ns2 {
		void foo (int a, int b) {
			cout << 3 << endl;
		}
		void bar (void) {
			foo (10, 20);
			ns1::foo (10);
			::foo ();
		}
	}
}
namespace nsa {
	void fun (int x) {
		cout << 'a' << endl;
	}
}
namespace nsb {
	void fun (double x) {
		cout << 'b' << endl;
	}
}
int main (void) {
	ns1::ns2::bar ();
	using namespace nsa;
	using namespace nsb;
	fun (100); // a
	fun (1.2); // b
	using nsa::fun;
	fun (100); // a
	fun (1.2); // a
	using nsb::fun;
	fun (100); // a
	fun (1.2); // b
	return 0;
}
