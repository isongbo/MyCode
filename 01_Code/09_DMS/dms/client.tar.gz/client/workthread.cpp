#include "workthread.h"
#include "logreader.h"
#include "socketsender.h"
#include "client.h"
void WorkThread::run (void) {
	try {
		LogReader reader ("./wtmpx", "./logins.dat");
		SocketSender sender ("./fail.dat", 8888,
			"192.168.0.26", this);
		Client client (reader, sender);
		client.dataMine ();
	}
	catch (exception& ex) {
		cout << ex.what () << endl;
	}
}
void WorkThread::update (string const& text) {
	emit (update (QString (text.c_str ())));
}
