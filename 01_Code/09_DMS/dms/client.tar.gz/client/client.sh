#!/bin/bash
cd /home/tarena/1405dms/client
./client
exit 0
