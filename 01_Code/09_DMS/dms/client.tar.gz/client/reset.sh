#!/bin/bash
rm -rf wtmpx.2014*
rm -rf *.dat
cp wtmpx.bak wtmpx
exit 0
