#include "workthread.h"
#include "logreader.h"
#include "socketsender.h"
#include "client.h"
void WorkThread::run (void) {
	/*
	emit (update ("Hello, World !"));
	sleep (1);
	emit (update ("Hello, World !"));
	sleep (1);
	emit (update ("Hello, World !"));
	sleep (1);
	emit (update ("Hello, World !"));
	sleep (1);
	emit (update ("Hello, World !"));
	*/
	try {
		LogReader reader ("./wtmpx",
			"./logins.dat");
		SocketSender sender ("./fail.dat",
			8888, "172.40.3.30", this);
		Client client (reader, sender);
		client.dataMine ();
	}
	catch (exception& ex) {
		cout << ex.what () << endl;
	}
}
void WorkThread::update (string const& text) {
	emit (update (QString (text.c_str ())));
}
