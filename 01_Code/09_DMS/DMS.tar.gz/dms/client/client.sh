#!/bin/bash
cd /home/tarena/1412/dms/client
./reset.sh
./client
exit 0
